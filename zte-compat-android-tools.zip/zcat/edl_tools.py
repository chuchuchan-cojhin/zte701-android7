"""
bkerler/edl(venv内にインストール済み)を、サブプロセスとして呼び出す、薄いラッパー。
呼び出し元は、edl_dir(deps.ensure_edl_tool() の戻り値)を渡すこと。
すべての書き込み系操作は、影響度(IMPACT)をログに残す。
"""
import os
import subprocess

from . import logger as logmod


def _edl_bin(edl_dir):
    return os.path.join(edl_dir, "venv", "bin", "edl")


def read_partition(edl_dir, loader_path, partition, out_path, memory="emmc", timeout=900):
    cmd = [
        _edl_bin(edl_dir), "r", partition, out_path,
        f"--loader={loader_path}", f"--memory={memory}",
    ]
    logmod.log_action(f"edl read {partition}", detail=out_path, impact=logmod.IMPACT_NONE)
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    logmod.log_command(cmd, r.returncode, r.stdout, r.stderr)
    return r


def write_sector(edl_dir, loader_path, start_sector, file_path, memory="emmc", timeout=300,
                  impact=logmod.IMPACT_USERDATA):
    cmd = [
        _edl_bin(edl_dir), "ws", str(start_sector), file_path,
        f"--loader={loader_path}", f"--memory={memory}",
    ]
    logmod.log_action(f"edl write sector {start_sector}", detail=file_path, impact=impact)
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    logmod.log_command(cmd, r.returncode, r.stdout, r.stderr)
    return r


def reset(edl_dir, loader_path, timeout=60):
    cmd = [_edl_bin(edl_dir), "reset", f"--loader={loader_path}"]
    logmod.log_action("edl reset (reboot out of EDL)", impact=logmod.IMPACT_NONE)
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    logmod.log_command(cmd, r.returncode, r.stdout, r.stderr)
    return r


def printgpt(edl_dir, loader_path, memory="emmc", timeout=120):
    cmd = [_edl_bin(edl_dir), "printgpt", f"--loader={loader_path}", f"--memory={memory}"]
    logmod.log_action("edl printgpt", impact=logmod.IMPACT_NONE)
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    logmod.log_command(cmd, r.returncode, r.stdout, r.stderr)
    return r
