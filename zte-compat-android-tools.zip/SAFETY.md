# 安全上の注意 / Safety Notes

## 日本語

- 本ツールは、Qualcomm EDL(緊急ダウンロードモード)を用いて、端末のパーティションを
  直接、読み書きします。**boot / aboot / sbl1 などの起動関連パーティションを誤って
  書き換えると、端末が起動しなくなる(いわゆる文鎮化)可能性があります。**
- 本ツールの「FTM直結ジェイルブレイク」機能は、**userdataパーティションのみ**を
  対象にしています。boot系パーティションは、デフォルトでは触れません。
  「アップグレード(実験的)」機能を使う場合のみ、boot系に触れる可能性があり、
  その際は、作業前に、必ず元のパーティションの、完全なバックアップを取ります。
- 使用しているEDLローダー(Firehoseファイル)は、**端末メーカーの署名と一致しないと
  動作しません**。署名が一致しないローダーを使うと、通信が応答しなくなることが
  ありますが、これ自体で端末が壊れることは、通常ありません(電池を抜いて再起動すれば
  復旧します)。
- 本ツールは、ベストエフォートで、安全策(事前バックアップ、書き込み後の検証、
  差分の大きさの確認)を講じますが、**ハードウェア・ファームウェアの個体差により、
  予期しない不具合が起こる可能性を、完全には排除できません。**
- **自分が所有する端末、または、所有者から明確な許可を得た端末にのみ、使用してください。**
- 作業前には、必ず、重要なデータの、別経路でのバックアップ(クラウド、PCなど)を
  取ってください。

## English

- This tool directly reads and writes device partitions via Qualcomm EDL
  (Emergency Download Mode). **Mistakenly flashing boot-critical partitions
  (boot / aboot / sbl1, etc.) can render the device unbootable ("bricked").**
- The "FTM Direct Jailbreak" feature only touches the `userdata` partition by
  default. Boot-related partitions are untouched unless you explicitly use the
  experimental "Upgrade" feature, which always backs up the original partition
  first.
- The Firehose loader used must match the device's manufacturer signature; a
  mismatched loader will simply fail to respond (recoverable by removing the
  battery and retrying) rather than damage the device.
- This tool makes a best effort at safety (pre-write backups, post-write
  verification, diff-size sanity checks) but **cannot guarantee against all
  hardware/firmware-specific issues.**
- **Use only on devices you own or have explicit permission to modify.**
- Always keep an independent backup of important data before proceeding.
