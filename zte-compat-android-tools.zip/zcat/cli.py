import os
import sys

from . import deps
from . import scan
from . import devices as device_registry
from . import workflows
from . import connection
from . import logger as logmod
from .i18n import I18n


def _pick_language():
    print("1) 日本語   2) English")
    choice = input("> ").strip()
    return "en" if choice == "2" else "ja"


def _pick_device(profiles, i18n):
    print(i18n.t("select_device"))
    for idx, p in enumerate(profiles):
        name = p["display_name"].get(i18n.lang, p["display_name"]["en"])
        print(f"  {idx + 1}) {name}  [{p.get('status', 'unknown')}]")
    choice = input("> ").strip()
    try:
        return profiles[int(choice) - 1]
    except (ValueError, IndexError):
        return profiles[0]


def _resolve_loader(profile, found, i18n):
    loader_name = profile["loader"]["filename"]
    for path in found.get("loader", []):
        if loader_name.split(".")[0] in os.path.basename(path):
            return path
    print(f"ローダーファイル({loader_name})が、見つかりませんでした。")
    print("プロファイルの source_url から、手動で入手し、パスを入力してください。")
    print(f"  source_url: {profile['loader']['source_url']}")
    return input("ローダーファイルのパス: ").strip()


def main():
    lang = _pick_language()
    i18n = I18n(lang)
    print(i18n.t("welcome"))

    if not deps.check_and_fix(i18n):
        sys.exit(1)

    profiles = device_registry.list_profiles()
    profile = _pick_device(profiles, i18n)

    found = scan.find_existing_files(i18n)
    loader_path = _resolve_loader(profile, found, i18n)

    edl_dir = deps.ensure_edl_tool(workflows.TOOLS_DIR, i18n)

    # --- ここが、今回、いちばん大事な変更点 ---
    # メインメニューを表示する前に、必ず、端末の接続状態を確認する。
    # 未接続なら、接続を促す。FTMモードなら、初期化なしのジェイルブレイクを、
    # 自動で行うかどうか、確認する。
    if not connection.ensure_device_ready(profile, loader_path, edl_dir, i18n):
        print(i18n.t("log_saved_to", path=logmod.current_log_path()))
        sys.exit(0)

    while True:
        print()
        print(i18n.t("menu_title"))
        for key in ["menu_scan", "menu_backup", "menu_jailbreak", "menu_restore",
                    "menu_apps", "menu_upgrade", "menu_lang", "menu_quit"]:
            print(i18n.t(key))
        choice = input("> ").strip()

        if choice == "0":
            print(i18n.t("log_saved_to", path=logmod.current_log_path()))
            break
        elif choice == "1":
            found = scan.find_existing_files(i18n)
        elif choice == "2":
            workflows.backup_userdata(profile, loader_path, edl_dir, i18n)
        elif choice == "3":
            workflows.jailbreak_ftm(profile, loader_path, edl_dir, i18n)
        elif choice == "4":
            backups = workflows.list_backups()
            if not backups:
                print(i18n.t("scan_none"))
                continue
            print(i18n.t("restore_select"))
            for idx, b in enumerate(backups):
                print(f"  {idx + 1}) {b}")
            sel = input("> ").strip()
            try:
                chosen = backups[int(sel) - 1]
            except (ValueError, IndexError):
                continue
            ans = input(i18n.t("restore_confirm")).strip().lower()
            if ans == "y":
                workflows.restore_from_backup(profile, loader_path, edl_dir, chosen, i18n)
        elif choice == "5":
            apk_paths = {}
            for key, app in profile["recommended_apps"].items():
                p = input(f"{app['name']} のAPKパス(空欄でスキップ): ").strip()
                if p:
                    apk_paths[key] = p
            workflows.install_recommended_apps(profile, apk_paths, i18n)
        elif choice == "6":
            print("アップグレード機能は、現在、実験段階のため、未実装です。"
                  " / The upgrade feature is experimental and not yet implemented.")
        elif choice == "7":
            lang = _pick_language()
            i18n.set_lang(lang)
        else:
            continue


if __name__ == "__main__":
    main()
