"""
端末ごとの固有情報(プロファイル)を、JSONから読み込む。
新しい端末への対応は、コードを変更せず、zcat/profiles/*.json を追加するだけでよい。
これが、本ツールの「中立性」「拡張性」の核となる部分。
"""
import json
import os
import glob

_PROFILE_DIR = os.path.join(os.path.dirname(__file__), "profiles")


def list_profiles():
    paths = sorted(glob.glob(os.path.join(_PROFILE_DIR, "*.json")))
    profiles = []
    for p in paths:
        with open(p, "r", encoding="utf-8") as f:
            profiles.append(json.load(f))
    return profiles


def load_profile(device_id):
    path = os.path.join(_PROFILE_DIR, f"{device_id}.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
