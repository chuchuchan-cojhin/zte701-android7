"""
言語の読み込みと、文字列の取得を行う、小さなモジュール。
新しい言語を足したいときは、zcat/lang/<コード>.json を追加するだけでよい。
"""
import json
import os

_LANG_DIR = os.path.join(os.path.dirname(__file__), "lang")
_SUPPORTED = ["ja", "en"]


class I18n:
    def __init__(self, lang="ja"):
        self.lang = lang if lang in _SUPPORTED else "ja"
        self._strings = {}
        self._load()

    def _load(self):
        path = os.path.join(_LANG_DIR, f"{self.lang}.json")
        with open(path, "r", encoding="utf-8") as f:
            self._strings = json.load(f)

    def set_lang(self, lang):
        self.lang = lang if lang in _SUPPORTED else self.lang
        self._load()

    def t(self, key, **kwargs):
        template = self._strings.get(key, key)
        try:
            return template.format(**kwargs)
        except Exception:
            return template

    @staticmethod
    def available_languages():
        return list(_SUPPORTED)
