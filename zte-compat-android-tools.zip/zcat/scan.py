"""
PC内・外部メディア(/media, /mnt 配下)から、既存のバックアップやローダーファイルを探す。
見つかれば、再ダウンロードせずに、それを使う。
"""
import os
import glob

SEARCH_ROOTS = [
    os.path.expanduser("~"),
    "/media",
    "/mnt",
    "/run/media",
]

# 探す対象のパターン(ファイル名の一部で判定する、ゆるい一致)
PATTERNS = {
    "loader": ["*firehose*.mbn", "*firehose*.elf"],
    "userdata_backup": ["userdata*.img", "userdata*.img.gz"],
    "full_partition_backup": ["*_backup", "*701zt_backup*", "*zte_backup*"],
}


def _safe_walk(root, max_depth=4):
    root = root.rstrip("/")
    base_depth = root.count("/")
    for dirpath, dirnames, filenames in os.walk(root, topdown=True):
        depth = dirpath.count("/") - base_depth
        if depth >= max_depth:
            dirnames[:] = []
        # 権限エラーや特殊ファイルシステムは黙って読み飛ばす
        yield dirpath, dirnames, filenames


def find_existing_files(i18n):
    found = {"loader": [], "userdata_backup": []}
    print(i18n.t("scan_local"))
    for root in SEARCH_ROOTS:
        if not os.path.isdir(root):
            continue
        try:
            for dirpath, _dirnames, filenames in _safe_walk(root):
                for fname in filenames:
                    lower = fname.lower()
                    full = os.path.join(dirpath, fname)
                    if "firehose" in lower and (lower.endswith(".mbn") or lower.endswith(".elf")):
                        found["loader"].append(full)
                    elif lower.startswith("userdata") and (lower.endswith(".img") or lower.endswith(".img.gz")):
                        found["userdata_backup"].append(full)
        except PermissionError:
            continue

    for category, items in found.items():
        for path in items:
            print(i18n.t("scan_found", path=path))

    if not any(found.values()):
        print(i18n.t("scan_none"))

    return found
