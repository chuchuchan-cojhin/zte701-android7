#!/usr/bin/env python3
"""ZTE互換Androidツールズ(ZCAT)の、起動用エントリーポイント。"""
from zcat.cli import main

if __name__ == "__main__":
    main()
