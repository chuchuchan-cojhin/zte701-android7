"""
バックアップ、復元、FTM直結ジェイルブレイク、アプリ自動導入の、各ワークフロー。
"""
import os
import time
import gzip
import shutil
from datetime import datetime

from . import adb_tools as adb
from . import edl_tools as edl
from . import diffpatch
from . import guide

WORK_DIR = os.path.expanduser("~/.zcat")
BACKUP_DIR = os.path.join(WORK_DIR, "backups")
TOOLS_DIR = os.path.join(WORK_DIR, "tools")


def _ensure_dirs():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    os.makedirs(TOOLS_DIR, exist_ok=True)


def _gzip_file(path):
    gz_path = path + ".gz"
    with open(path, "rb") as f_in, gzip.open(gz_path, "wb", compresslevel=1) as f_out:
        shutil.copyfileobj(f_in, f_out)
    os.remove(path)
    return gz_path


def _gunzip_file(gz_path, out_path):
    with gzip.open(gz_path, "rb") as f_in, open(out_path, "wb") as f_out:
        shutil.copyfileobj(f_in, f_out)
    return out_path


# ---------------------------------------------------------------------------
# バックアップ
# ---------------------------------------------------------------------------

def backup_userdata(profile, loader_path, edl_dir, i18n):
    _ensure_dirs()
    if not adb.wait_for_device(timeout=5):
        print(i18n.t("error_no_device"))
        print("EDLモードにすでに入っている場合は、このまま続行します。"
              " / If the device is already in EDL mode, continuing anyway.")
    else:
        adb.reboot_edl()
        time.sleep(5)

    ts = datetime.now().strftime("%Y%m%d_%H%M")
    out_path = os.path.join(BACKUP_DIR, f"userdata_{ts}.img")
    print(i18n.t("edl_reading"))
    edl.read_partition(edl_dir, loader_path, "userdata", out_path)

    print(i18n.t("backup_saving", path=out_path))
    gz_path = _gzip_file(out_path)
    print(i18n.t("backup_done", path=gz_path))
    return gz_path


def list_backups():
    _ensure_dirs()
    return sorted(
        [os.path.join(BACKUP_DIR, f) for f in os.listdir(BACKUP_DIR) if f.endswith(".img.gz")],
        reverse=True,
    )


# ---------------------------------------------------------------------------
# FTM直結ジェイルブレイク(初期化なし)
# ---------------------------------------------------------------------------

def jailbreak_ftm(profile, loader_path, edl_dir, i18n):
    """
    工場出荷時初期化を一切行わず、以下だけで ADB を有効化する:
      FTM起動 -> adb reboot edl -> userdataを読み出し ->
      対象プロパティだけ書き換え -> 差分だけ書き戻し -> 通常起動
    """
    _ensure_dirs()
    guide.show_ftm_guide(profile, i18n)

    print(i18n.t("adb_waiting"))
    if not adb.wait_for_device(timeout=60):
        print(i18n.t("error_no_device"))
        return False
    print(i18n.t("adb_found", serial=adb.devices()[0]))

    print(i18n.t("edl_entering"))
    adb.reboot_edl()
    time.sleep(5)

    current_path = os.path.join(WORK_DIR, "current_userdata.img")
    print(i18n.t("edl_reading"))
    edl.read_partition(edl_dir, loader_path, "userdata", current_path)

    # 現状を、対象ファイルシステムとして一時マウントし、プロパティだけ編集した
    # コピーを作る(マウントにはsudoが必要なため、呼び出し元のOS側で、権限があることを前提とする)。
    target_path = os.path.join(WORK_DIR, "target_userdata.img")
    shutil.copyfile(current_path, target_path)
    patch = profile["jailbreak_patch"]
    print(i18n.t("patch_applying", key=patch["property_key"], value=patch["to_value"]))
    _patch_property_in_image(target_path, patch["target_file"], patch["to_value"])

    print(i18n.t("diff_computing"))
    part = profile["partitions"]
    diff_info = diffpatch.compute_diff(
        current_path, target_path,
        out_dir=os.path.join(WORK_DIR, "patch_work"),
        partition_start_sector=part["userdata_start_sector"],
        block_to_sector=part["block_to_sector"],
    )
    print(i18n.t("diff_size", mb=round(diff_info["total_mb"], 2), blocks=diff_info["blocks"]))

    if diff_info["total_mb"] > 500:
        ans = input(i18n.t("diff_large_warn")).strip().lower()
        if ans != "y":
            print(i18n.t("cancelled"))
            return False

    print(i18n.t("writing_patch"))
    for sector, file_path in diffpatch.load_patch_commands(diff_info["cmds_path"]):
        edl.write_sector(edl_dir, loader_path, sector, file_path)

    print(i18n.t("verifying"))
    verify_path = os.path.join(WORK_DIR, "verify_userdata.img")
    edl.read_partition(edl_dir, loader_path, "userdata", verify_path)
    if not _files_equal(verify_path, target_path):
        print(i18n.t("verify_fail"))
        return False
    print(i18n.t("verify_ok"))

    edl.reset(edl_dir, loader_path)
    print(i18n.t("rebooting_normal"))
    time.sleep(10)
    adb.wait_for_device(timeout=60)
    print(i18n.t("jailbreak_success"))
    return True


def _patch_property_in_image(image_path, target_file_in_fs, new_value):
    """
    f2fsイメージ内の、1つのプロパティファイルを、ループバックマウントして書き換える。
    sudoが必要。中身はそのまま上書きし、所有者・権限・SELinuxラベルは変更しない。
    """
    mount_point = os.path.join(WORK_DIR, "mnt")
    os.makedirs(mount_point, exist_ok=True)
    os.system(f"sudo mount -o rw,loop {image_path} {mount_point}")
    try:
        full_path = os.path.join(mount_point, target_file_in_fs.lstrip("/"))
        os.system(f"printf '%s' '{new_value}' | sudo tee {full_path} > /dev/null")
    finally:
        os.system(f"sudo umount {mount_point}")


def _files_equal(path_a, path_b, chunk=1024 * 1024):
    with open(path_a, "rb") as fa, open(path_b, "rb") as fb:
        while True:
            ca = fa.read(chunk)
            cb = fb.read(chunk)
            if ca != cb:
                return False
            if not ca:
                return True


# ---------------------------------------------------------------------------
# 復元
# ---------------------------------------------------------------------------

def restore_from_backup(profile, loader_path, edl_dir, backup_gz_path, i18n):
    _ensure_dirs()
    target_path = os.path.join(WORK_DIR, "restore_target.img")
    _gunzip_file(backup_gz_path, target_path)

    if not adb.wait_for_device(timeout=5):
        print("EDLモードのまま、続行します。 / Continuing, assuming device is already in EDL.")
    else:
        adb.reboot_edl()
        time.sleep(5)

    current_path = os.path.join(WORK_DIR, "current_for_restore.img")
    print(i18n.t("edl_reading"))
    edl.read_partition(edl_dir, loader_path, "userdata", current_path)

    print(i18n.t("diff_computing"))
    part = profile["partitions"]
    diff_info = diffpatch.compute_diff(
        current_path, target_path,
        out_dir=os.path.join(WORK_DIR, "restore_patch_work"),
        partition_start_sector=part["userdata_start_sector"],
        block_to_sector=part["block_to_sector"],
    )
    print(i18n.t("diff_size", mb=round(diff_info["total_mb"], 2), blocks=diff_info["blocks"]))

    print(i18n.t("writing_patch"))
    for sector, file_path in diffpatch.load_patch_commands(diff_info["cmds_path"]):
        edl.write_sector(edl_dir, loader_path, sector, file_path)

    print(i18n.t("verifying"))
    verify_path = os.path.join(WORK_DIR, "restore_verify.img")
    edl.read_partition(edl_dir, loader_path, "userdata", verify_path)
    if not _files_equal(verify_path, target_path):
        print(i18n.t("verify_fail"))
        return False
    print(i18n.t("verify_ok"))

    edl.reset(edl_dir, loader_path)
    print(i18n.t("rebooting_normal"))
    return True


# ---------------------------------------------------------------------------
# アプリの自動導入
# ---------------------------------------------------------------------------

def install_recommended_apps(profile, apk_paths, i18n):
    """
    apk_paths: {"launcher": "/path/to/nova.apk", "browser_primary": "/path/to/firefox.apk", ...}
    各APKは、呼び出し元が、プロファイルのsource_noteに従って、あらかじめ用意しておく。
    (本ツールは、著作権のあるAPKを、無断で同梱・自動ダウンロードはしない)
    """
    apps = profile["recommended_apps"]
    for key, path in apk_paths.items():
        if key not in apps or not path or not os.path.isfile(path):
            continue
        name = apps[key]["name"]
        print(i18n.t("apps_installing", name=name))
        ok = adb.install(path)
        if not ok:
            print(f"  -> {name}: インストールに失敗しました。 / install failed.")
    print(i18n.t("apps_done"))
