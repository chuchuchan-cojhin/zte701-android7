"""
FTMモードへの入り方を、プロファイルの情報(ボタン組み合わせ・保持秒数)を元に、
checkra1nのような、カウントダウン付きで、画面に表示する。
"""
import sys
import time


def show_ftm_guide(profile, i18n):
    lang = i18n.lang
    print()
    print("=" * 50)
    print(i18n.t("ftm_guide_title"))
    print("-" * 50)
    print(profile["ftm_entry"].get(lang, profile["ftm_entry"]["en"]))
    print("=" * 50)
    input(i18n.t("press_enter"))

    seconds = profile["ftm_entry"].get("hold_seconds", 5)
    for remaining in range(seconds, 0, -1):
        sys.stdout.write("\r" + i18n.t("ftm_guide_wait", sec=remaining) + "   ")
        sys.stdout.flush()
        time.sleep(1)
    print()
    print(i18n.t("ftm_guide_done"))
