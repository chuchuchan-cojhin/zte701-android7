"""
2つのイメージファイル(読み出した現状 と 目標の状態)を比較し、
異なるブロックだけを抽出して、個別セクタ書き込み用のパッチ群を作る。

丸ごと書き込むより、はるかに高速・安全(userdataの数GBに対し、
実際の差分は、多くの場合、数MB〜数百MB程度に収まる)。
"""
import os

BLOCK = 4096          # f2fs の論理ブロックサイズ
CHUNK = BLOCK * 4096  # 一度にメモリへ読む単位(16MB)
GAP = 256             # 近傍のブロックは1つの範囲にまとめる(ブロック数)


def compute_diff(current_path, target_path, out_dir, partition_start_sector,
                  sector_size=512, block_to_sector=8):
    """
    partition_start_sector: そのパーティションの、ディスク上の開始セクタ
    block_to_sector: 1ブロック(4096バイト)あたりのセクタ数(通常 4096/512=8)
    """
    os.makedirs(out_dir, exist_ok=True)
    diff_blocks = []
    offset = 0
    with open(current_path, "rb") as fa, open(target_path, "rb") as fb:
        while True:
            a = fa.read(CHUNK)
            b = fb.read(CHUNK)
            if not a and not b:
                break
            if a != b:
                for i in range(0, len(a), BLOCK):
                    if a[i:i + BLOCK] != b[i:i + BLOCK]:
                        diff_blocks.append((offset + i) // BLOCK)
            offset += len(a)

    ranges = []
    for blk in diff_blocks:
        if ranges and blk - ranges[-1][1] <= GAP:
            ranges[-1][1] = blk + 1
        else:
            ranges.append([blk, blk + 1])

    total_bytes = sum((e - s) * BLOCK for s, e in ranges)

    cmds_path = os.path.join(out_dir, "cmds.txt")
    with open(target_path, "rb") as fb, open(cmds_path, "w") as out:
        for n, (s, e) in enumerate(ranges):
            fb.seek(s * BLOCK)
            patch_file = os.path.join(out_dir, f"p{n:03d}.bin")
            with open(patch_file, "wb") as pf:
                pf.write(fb.read((e - s) * BLOCK))
            sector = partition_start_sector + s * block_to_sector
            out.write(f"{sector} {patch_file}\n")

    return {
        "blocks": len(diff_blocks),
        "ranges": len(ranges),
        "total_mb": total_bytes / 1e6,
        "cmds_path": cmds_path,
    }


def load_patch_commands(cmds_path):
    commands = []
    with open(cmds_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            sector_str, path = line.split(" ", 1)
            commands.append((int(sector_str), path))
    return commands
