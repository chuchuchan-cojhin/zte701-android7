# ZTE互換Androidツールズ (ZTE Compatible Android Tools / zcat)

> Qualcomm EDL(Emergency Download Mode)を使った、ZTE系(および、互換のある)Android端末向けの、
> バックアップ・復元・初期化不要の機能解放ツールです。3uToolsのような、総合ツールを目指していますが、
> 現在は **CLI(コマンドライン)版のv0.1** です。GUIはロードマップに含まれます。

English summary: A CLI toolkit for Qualcomm-EDL-capable ZTE-family Android devices.
Backup / restore / "no factory reset" feature-unlock via direct FTM→EDL→userdata-patch workflow.
GUI is planned but not yet implemented (see ROADMAP below).

---

## このツールが生まれた経緯

ソフトバンクのキッズケータイ「701ZT」(ZTE製)で、保護者向け制限により隠されていた
USBデバッグ機能を解放する過程で、試行錯誤の末に見つかった手法を、汎用化したものです。

当初は「工場出荷時初期化 → EDLでuserdata編集」という手順を踏みましたが、
**実際には初期化は不要**で、以下の手順だけで十分なことが、後から判明しました。

```
電源OFF
  → FTMモードで起動(多くのZTE機は 電源+音量マイナス 長押し)
  → adb reboot edl
  → EDLでuserdataパーティションを読み出し
  → persist.sys.usb.config などの対象プロパティだけを書き換え
  → 差分だけをEDLで書き戻し(全体書き込みより高速・安全)
  → 通常起動 → adb devicesで認識を確認
```

このツールは、この「初期化なしFTM直結ジェイルブレイク」を、**主要機能**として実装しています。

## 対応方針(中立性について)

- このツールのコア部分(CLI、依存関係チェック、EDL/ADBラッパー、差分パッチ処理)は、
  **特定の端末に依存しない、汎用的なコード**です。
- 端末ごとの固有情報(ローダーの入手元、PK_HASH、パッチ対象のプロパティ、既知の制約)は、
  `zcat/profiles/*.json` に**分離**されています。これにより、701ZT以外の、
  同系統のZTE端末(あるいは、同じQualcomm EDL機構を持つ他社端末)についても、
  **プロファイルを追加するだけで、対応を広げられる**設計です。
- 公式のファームウェア配布元や、検証済みのローダーの出典は、必ずプロファイル内に明記し、
  出典不明のバイナリを、ツール側から無断で同梱・自動実行することはありません。

## できること(v0.1, CLI)

| 機能 | 状態 |
|---|---|
| 依存関係の自動チェック・インストール(apt系Linux) | ✅ |
| 既存のバックアップ/ローダーの自動検出(PC内・外部メディア) | ✅ |
| userdataの丸ごとバックアップ | ✅ |
| 初期化なしFTM直結ジェイルブレイク(ADB有効化) | ✅ |
| 差分パッチによる高速・安全な書き戻し | ✅ |
| バックアップからの復元 | ✅ |
| Nova Launcher + Iceraven(ブラウザ)の自動導入 | ✅ |
| 日本語/英語の切り替え | ✅ |
| FTMモード突入のガイド表示(カウントダウン付き) | ✅ |
| アップグレード機能(カスタムROM化など) | 🧪 実験的・未実装(ロードマップ) |
| GUI(3uTools的な画面) | 📋 ロードマップ |

## 安全上の注意

**必ず `SAFETY.md` を先にお読みください。** bootやabootなど、起動の根幹に関わる
パーティションを扱う操作は、端末が起動しなくなるリスクを伴います。本ツールは、
書き込み前に自動でバックアップを取りますが、**100%の安全を保証するものではありません**。

## インストール

```bash
git clone https://github.com/yourname/zte-compat-android-tools.git
cd zte-compat-android-tools
python3 zcat.py
```

初回起動時に、不足している依存関係(adb, fastboot, python3-venv, git など)を
自動検出し、インストールするか確認します。

## 対応言語

実行時に、日本語 / English を選択できます。`zcat/lang/*.json` を編集・追加することで、
他言語への翻訳も歓迎します。

## ロードマップ

- [ ] GUI版(Tkinter または Web UI)
- [ ] 他のZTE系端末プロファイルの追加(コミュニティ提供歓迎)
- [ ] カスタムROM書き込み機能の、実験的サポート
- [ ] Windows/macOS対応(現状はDebian系Linuxのみ)

## ライセンス

MIT License(`LICENSE`参照)。本ツールは、個人の端末の、自己所有デバイスに対する
カスタマイズを目的としています。他者の端末への、無断での使用は、禁止されています。
