"""
メインメニューを表示する「前」に、必ず、接続状態を確認するための、モジュール。

状態は、次の4つを区別する:
  NORMAL       - 通常起動で、ADB(フルのAndroidフレームワーク)が、使える
  FTM          - ADBは応答するが、Package Managerが無く、FTM(診断モード)だと判定
  EDL          - lsusbで、Qualcomm 9008系のデバイスが見えている
  DISCONNECTED - 何も、見つからない

FTMのときは、「初期化なしFTM直結ジェイルブレイク」を、自動で、実行するか、確認する。
"""
import subprocess

from . import adb_tools as adb
from . import workflows
from . import logger as logmod

STATE_NORMAL = "NORMAL"
STATE_FTM = "FTM"
STATE_EDL = "EDL"
STATE_DISCONNECTED = "DISCONNECTED"


def _lsusb_output():
    try:
        r = subprocess.run(["lsusb"], capture_output=True, text=True, timeout=10)
        return r.stdout
    except Exception:
        return ""


def _is_edl_present(profile):
    edl_id = profile.get("edl_usb_id", "05c6:9008")
    return edl_id.lower() in _lsusb_output().lower()


def _adb_looks_like_ftm():
    """
    FTMでは、Package Managerが起動していないため、pm list packagesが、
    特徴的なエラー文言を返す。これを、FTM判定の目印にする。
    """
    out = adb.shell("pm list packages", timeout=10)
    return ("Could not access the Package Manager" in out) or (out.strip() == "")


def detect_state(profile):
    if _is_edl_present(profile):
        logmod.log_action("接続状態の検出", detail="EDLモードのデバイスを検出", impact=logmod.IMPACT_NONE)
        return STATE_EDL

    if adb.devices():
        if _adb_looks_like_ftm():
            logmod.log_action("接続状態の検出", detail="FTMモードのデバイスを検出", impact=logmod.IMPACT_NONE)
            return STATE_FTM
        logmod.log_action("接続状態の検出", detail="通常起動のデバイスを検出", impact=logmod.IMPACT_NONE)
        return STATE_NORMAL

    logmod.log_action("接続状態の検出", detail="デバイスが見つからない", impact=logmod.IMPACT_NONE)
    return STATE_DISCONNECTED


def ensure_device_ready(profile, loader_path, edl_dir, i18n):
    """
    端末が、通常起動でADBが使える状態(STATE_NORMAL)になるまで、
    案内・自動対応を、繰り返す。メインメニューは、この関数が
    True を返すまで、表示しない。
    """
    while True:
        print()
        print(i18n.t("connection_checking"))
        state = detect_state(profile)

        if state == STATE_NORMAL:
            print(i18n.t("connection_normal_ready"))
            return True

        if state == STATE_FTM:
            print(i18n.t("connection_ftm_detected"))
            ans = input(i18n.t("connection_ftm_offer")).strip().lower()
            if ans == "y":
                ok = workflows.jailbreak_ftm(profile, loader_path, edl_dir, i18n)
                if ok:
                    continue  # 成功したら、もう一度、状態確認からやり直す
                else:
                    print(i18n.t("connection_retry"))
                    cont = input(i18n.t("connection_connect_prompt")).strip().lower()
                    if cont == "q":
                        return False
                    continue
            else:
                cont = input(i18n.t("connection_connect_prompt")).strip().lower()
                if cont == "q":
                    return False
                continue

        if state == STATE_EDL:
            print(i18n.t("connection_edl_detected"))
            cont = input(i18n.t("connection_connect_prompt")).strip().lower()
            if cont == "q":
                return False
            continue

        # DISCONNECTED
        print(i18n.t("connection_none"))
        cont = input(i18n.t("connection_connect_prompt")).strip().lower()
        if cont == "q":
            return False
        continue
