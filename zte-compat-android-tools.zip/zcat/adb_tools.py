"""ADBの、薄いラッパー。すべての呼び出しを、ログに残す。"""
import subprocess
import time

from . import logger as logmod


def run(args, timeout=30):
    cmd = ["adb"] + args
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        logmod.log_command(cmd, r.returncode, r.stdout, r.stderr)
        return r
    except subprocess.TimeoutExpired as e:
        logmod.log_command(cmd, "TIMEOUT", "", str(e))
        raise


def devices():
    r = run(["devices"])
    lines = [l for l in r.stdout.splitlines()[1:] if l.strip()]
    return [l.split("\t")[0] for l in lines if "\tdevice" in l]


def wait_for_device(timeout=60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if devices():
            return True
        time.sleep(1)
    return False


def shell(cmd, timeout=30):
    r = run(["shell", cmd], timeout=timeout)
    return r.stdout.strip()


def shell_ok(cmd, timeout=30):
    """標準出力と、コマンドが成功したとみなせるかの、両方を返す。"""
    r = run(["shell", cmd], timeout=timeout)
    return r.stdout.strip(), r.returncode == 0


def reboot_edl():
    logmod.log_action("adb reboot edl", impact=logmod.IMPACT_NONE)
    run(["reboot", "edl"])


def reboot_normal():
    logmod.log_action("adb reboot", impact=logmod.IMPACT_NONE)
    run(["reboot"])


def install(apk_path, timeout=120):
    logmod.log_action("adb install", detail=apk_path, impact=logmod.IMPACT_APP)
    r = run(["install", apk_path], timeout=timeout)
    return "Success" in r.stdout


def getprop(key):
    return shell(f"getprop {key}")
