"""
詳細ログを、ファイルとコンソールの、両方に出す、小さなロガー。
各操作には「端末への影響度」のタグを付け、何かあったときに、
「どこまで、端末に、手を加えたか」を、追えるようにする。
"""
import logging
import os
from datetime import datetime

LOG_DIR = os.path.expanduser("~/.zcat/logs")

IMPACT_NONE = "影響なし(読み取りのみ) / no-impact (read-only)"
IMPACT_USERDATA = "userdataパーティションに影響 / affects userdata partition"
IMPACT_BOOT = "起動関連パーティションに影響(高リスク) / affects boot-related partition (HIGH RISK)"
IMPACT_APP = "アプリの追加/削除のみ / app install/uninstall only"


def _ensure_log_dir():
    os.makedirs(LOG_DIR, exist_ok=True)


def get_logger():
    _ensure_log_dir()
    logger = logging.getLogger("zcat")
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(LOG_DIR, f"zcat_{ts}.log")

    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)

    logger.current_log_path = log_path
    return logger


def log_action(action, detail="", impact=IMPACT_NONE, result=None):
    logger = get_logger()
    msg = f"ACTION={action} | IMPACT={impact} | DETAIL={detail}"
    if result is not None:
        msg += f" | RESULT={result}"
    logger.info(msg)


def log_command(cmd_list, returncode, stdout="", stderr=""):
    logger = get_logger()
    logger.debug(
        "CMD=%s | RC=%s | STDOUT=%s | STDERR=%s",
        " ".join(str(c) for c in cmd_list), returncode,
        (stdout or "")[:2000], (stderr or "")[:2000],
    )


def current_log_path():
    return get_logger().current_log_path
