"""
実行に必要な外部ツールを確認し、不足していれば、確認のうえ、自動でインストールする。
対応は、現状 apt 系 Linux(Debian / Ubuntu / Linux Mint)のみ。
他OSの場合は、不足分を一覧表示し、手動インストールを案内する。
"""
import shutil
import subprocess
import sys
import os

# コマンド名 -> apt パッケージ名
REQUIRED_TOOLS = {
    "adb": "android-tools-adb",
    "fastboot": "android-tools-fastboot",
    "git": "git",
    "python3": "python3",
}

# venv 作成に必要(distro によってパッケージ名が変わるため、python3-venv を既定とする)
VENV_PACKAGE = "python3-venv"

EDL_REPO_URL = "https://github.com/bkerler/edl.git"


def _is_apt_system():
    return shutil.which("apt") is not None


def missing_tools():
    return [cmd for cmd in REQUIRED_TOOLS if shutil.which(cmd) is None]


def install_tools(missing, i18n):
    if not _is_apt_system():
        print(i18n.t("deps_missing", items=", ".join(missing)))
        print("この環境では、自動インストールに対応していません。手動で導入してください。"
              " / Automatic install is not supported on this system; please install manually.")
        return False

    packages = [REQUIRED_TOOLS[c] for c in missing]
    subprocess.run(["sudo", "apt", "update"], check=False)
    result = subprocess.run(["sudo", "apt", "install", "-y"] + packages)
    return result.returncode == 0


def ensure_python_venv():
    """python3-venv が無い場合に備えて、確認だけ行う(apt系のみ自動導入)。"""
    try:
        import venv  # noqa: F401
        return True
    except ImportError:
        if _is_apt_system():
            subprocess.run(["sudo", "apt", "install", "-y", VENV_PACKAGE])
        return True


def ensure_edl_tool(tools_dir, i18n):
    """
    bkerler/edl が、ローカルに無ければ、取得して venv を作る。
    すでにあれば、そのパスを返すだけ(ネットに繋がず再利用)。
    """
    edl_dir = os.path.join(tools_dir, "edl")
    if os.path.isdir(edl_dir):
        return edl_dir

    os.makedirs(tools_dir, exist_ok=True)
    subprocess.run(["git", "clone", EDL_REPO_URL, edl_dir], check=True)
    ensure_python_venv()
    venv_dir = os.path.join(edl_dir, "venv")
    subprocess.run([sys.executable, "-m", "venv", venv_dir], check=True)
    pip = os.path.join(venv_dir, "bin", "pip")
    subprocess.run([pip, "install", "."], cwd=edl_dir, check=True)
    return edl_dir


def check_and_fix(i18n, auto_yes=False):
    print(i18n.t("deps_checking"))
    missing = missing_tools()
    if not missing:
        print(i18n.t("deps_ok"))
        return True

    print(i18n.t("deps_missing", items=", ".join(missing)))
    if not auto_yes:
        ans = input(i18n.t("deps_install_confirm")).strip().lower()
        if ans != "y":
            print(i18n.t("cancelled"))
            return False
    return install_tools(missing, i18n)
